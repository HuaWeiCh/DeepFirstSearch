#ifndef _CACULATE_H_
#define	_CACULATE_H_

void caculate(char* str);
int str_to_num(char* char_p,int* int_p,float* float_p);
void step_move_int(int step,int* temp_p);
void step_move_float(int step,float* temp_p);
void caculate_int(int* int_p);
void caculate_float(float* float_p);

#endif	
