//////////////////////////////////////////////////////////////
//1.����һ���ַ�ת�����������
//3.�ַ�ʽ���в��ܳ��ֿո�
//4.֧�ּӼ��˳��������
//2.֧��ʽ�������ŵ����ȼ�
//5.ֻ������������Ϊ����������ʱǿ����ȥС������
//6.ֻҪ��С������ڣ�������ʽ�ӽ����и���������
//////////////////////////////////////////////////////////////
#include "caculate.h"
#include <stdio.h>


void caculate(char* str)
{
	int flag;
	static int	 int_num[120]={0};
	static float float_num[120]={0};

	printf("Input:%s\n",str);
	flag=str_to_num(str,int_num,float_num);

	if(0==flag)
	{
		caculate_int(int_num);
		printf("The result:%d\n",int_num[0]);
	}
	else
	{
		caculate_float(float_num);
		printf("The result:%f\n",float_num[0]);
	}
}
//*****************************str_to_num����**********************************
//����ʱӦ����ո�ĳ���,��������
//����1��Ϊ�����ͣ�����0��Ϊ����
int str_to_num(char* char_p,int* int_p,float* float_p)
{
	char *p=char_p;
	int  temp=0;
	int   temp0=0;
	float temp1=0;

	int   if_float_flag=0;
	float conversion_ratio=10;
	int   if_visit_point=0;
	
	while(*p != 0)	//�Ƿ���ڸ�����
	{
		if('.'==*p)
		{
			if_float_flag=1;
			break;
		}
		p++;
	}
	
	temp=*char_p;
	while(temp!=0)
	{
		if((temp>=48)&&(temp<=57))
		{
			while(((temp>=48)&&(temp<=57))||('.'==temp))
			{
				if(0==if_float_flag)
				{
					temp0=temp0*10+temp-48;
					char_p++;
					temp=*char_p;
				}
				else
				{
					if('.'==temp)
					{
						if_visit_point=1;
						char_p++;
						temp=*char_p;
					}

					if(0==if_visit_point)
					{
						temp1=temp1*10+temp-48;
					}
					else
					{
						temp1=temp1+(float)(temp-48)/conversion_ratio;
						conversion_ratio*=10;
					}
					char_p++;
					temp=*char_p;
				}
			}
			if(0==if_float_flag)
			{
				*int_p=temp0;
				int_p++;
				temp0=0;
			}
			else
			{
				*float_p=temp1;
				float_p++;
				conversion_ratio=10;
				temp1=0;
			}

			if_visit_point=0;
		}
		else if(('+'==temp)||('-'==temp)||('*'==temp)||('/'==temp)||('('==temp)||(')'==temp))
		{
			if(0==if_float_flag)
			{
				*int_p=*char_p;
				int_p++;
				char_p++;
				temp=*char_p;
			}
			else
			{
				*float_p=*char_p;
				float_p++;
				char_p++;
				temp=*char_p;
			}
		}
		else
		{
			char_p++;
			temp=*char_p;
		}
	}

	return if_float_flag;
}
//****************************************************************************
void step_move_int(int step,int* temp_p)
{
	int i;
	int temp;

	for(i=0;i<step+1;i++)	temp_p++;
	do		//�Ƴ���������ķ��ż�����
	{
		temp=*temp_p;
		for(i=0;i<step;i++)	temp_p--;
		*temp_p=temp;
		temp_p++;
		temp=*temp_p;
		for(i=0;i<step;i++)	temp_p++;
	}while(temp != 0);
}
//****************************************************************************
void step_move_float(int step,float* temp_p)
{
	int i;
	float temp;

	for(i=0;i<step+1;i++)	temp_p++;
	do		//�Ƴ���������ķ��ż�����
	{
		temp=*temp_p;
		for(i=0;i<step;i++)	temp_p--;
		*temp_p=temp;
		temp_p++;
		temp=*temp_p;
		for(i=0;i<step;i++)	temp_p++;
	}while(temp != 0);
}
//****************************************************************************
void caculate_int(int* int_p)
{
	int  temp;
	int* p_int=int_p;

	while(*p_int != 0)	//�Ƿ����(
	{
		if('('==*p_int)
		{
			p_int++;
			caculate_int(p_int);
			p_int--;
			p_int--;
			step_move_int(1,p_int);
			break;
		}
		p_int++;
	}

	p_int=int_p;
	while((*p_int != 0)&&(*p_int != ')'))
	{
		if('*'==*p_int)
		{
			p_int++;
			temp=*p_int;
			p_int--;
			p_int--;
			*p_int *= temp;
			step_move_int(2,p_int);
		}
		if('/'==*p_int)
		{
			p_int++;
			temp=*p_int;
			p_int--;
			p_int--;
			*p_int /= temp;
			step_move_int(2,p_int);
		}

		p_int++;
	}

	p_int=int_p;
	while((*p_int != 0)&&(*p_int != ')'))
	{
		if('+'==*p_int)
		{
			p_int++;
			temp=*p_int;
			p_int--;
			p_int--;
			*p_int += temp;
			step_move_int(2,p_int);
		}
		if('-'==*p_int)
		{
			p_int++;
			temp=*p_int;
			p_int--;
			p_int--;
			*p_int -= temp;
			step_move_int(2,p_int);
		}

		p_int++;
	}

	if(*p_int == ')')
	{
		p_int--;
		step_move_int(1,p_int);
	}
}
//****************************************************************************
void caculate_float(float* float_p)
{
	float temp;
	float* p_float=float_p;

	while(*p_float != 0)	//�Ƿ����(
	{
		if('('==*p_float)
		{
			p_float++;
			caculate_float(p_float);
			p_float--;
			p_float--;
			step_move_float(1,p_float);
			break;
		}
		p_float++;
	}
	
	p_float=float_p;
	while((*p_float != 0)&&(*p_float != ')'))
	{
		if('*'==*p_float)
		{
			p_float++;
			temp=*p_float;
			p_float--;
			p_float--;
			*p_float *= temp;
			step_move_float(2,p_float);
		}
		if('/'==*p_float)
		{
			p_float++;
			temp=*p_float;
			p_float--;
			p_float--;
			*p_float /= temp;
			step_move_float(2,p_float);
		}

		p_float++;
	}
	
	p_float=float_p;
	while((*p_float != 0)&&(*p_float != ')'))
	{
		if('+'==*p_float)
		{
			p_float++;
			temp=*p_float;
			p_float--;
			p_float--;
			*p_float += temp;
			step_move_float(2,p_float);
		}
		if('-'==*p_float)
		{
			p_float++;
			temp=*p_float;
			p_float--;
			p_float--;
			*p_float -= temp;
			step_move_float(2,p_float);
		}

		p_float++;
	}

	if(*p_float == ')')
	{
		p_float--;
		step_move_float(1,p_float);
	}
}